<div class="px-4 py-3 d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center">
    </div>

    <div class="ms-auto">
        <div class="small">
            Signed in as<br>
            <strong>{{ auth()->user()->name ?? 'Admin' }}</strong>
        </div>
    </div>
</div>

