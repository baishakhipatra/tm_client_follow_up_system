<div class="px-4 py-3 d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center">
    </div>

    <div class="ms-auto">
        <div class="small">
            Signed in as<br>
            <strong><?php echo e(auth()->user()->name ?? 'Admin'); ?></strong>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp2\htdocs\TM_follow_up_system\resources\views/partials/header.blade.php ENDPATH**/ ?>