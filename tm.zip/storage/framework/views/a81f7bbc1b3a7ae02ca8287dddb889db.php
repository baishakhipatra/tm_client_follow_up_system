<div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark"
     style="width:260px; min-height:100vh;">

    
    <a href="<?php echo e(route('dashboard')); ?>" class="d-flex align-items-center mb-4 text-white text-decoration-none">
        <img src="<?php echo e(asset('logo.png')); ?>" height="55" class="me-2">
    </a>

    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item mb-2">
            <a href="<?php echo e(route('dashboard')); ?>"
            class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                <i class="bi bi-house me-2"></i> Dashboard
            </a>
        </li>

        <li class="nav-item mb-2">
            <a href="<?php echo e(route('admin.clients.index')); ?>"
            class="nav-link <?php echo e(request()->routeIs('admin.clients.index') ? 'active' : ''); ?>">
                <i class="bi bi-people me-2"></i> Clients
            </a>
        </li>

        <li class="nav-item mb-2">
            <a href="<?php echo e(route('admin.projects.index')); ?>"
            class="nav-link <?php echo e(request()->routeIs('admin.projects.index') ? 'active' : ''); ?>">
                <i class="bi bi-folder me-2"></i> Projects
            </a>
        </li>

        <li class="nav-item mb-2">
            <a href="<?php echo e(route('admin.invoices.index')); ?>"
            class="nav-link <?php echo e(request()->routeIs('admin.invoices.index') ? 'active' : ''); ?>">
                <i class="bi bi-receipt me-2"></i> Invoices
            </a>
        </li>
    </ul>

    <hr>

    
    <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-3">
        <?php echo csrf_field(); ?>
        <button class="btn btn-outline-light btn-sm w-100">
            Sign out
        </button>
    </form>
</div>
<?php /**PATH C:\xampp2\htdocs\TM_follow_up_system\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>